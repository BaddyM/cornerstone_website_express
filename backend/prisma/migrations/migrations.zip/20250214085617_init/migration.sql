-- AlterTable
ALTER TABLE `Messages` ADD COLUMN `image` VARCHAR(200) NULL;
