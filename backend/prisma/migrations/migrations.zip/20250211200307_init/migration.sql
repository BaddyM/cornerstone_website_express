-- AlterTable
ALTER TABLE `Events` MODIFY `date` VARCHAR(100) NOT NULL;
